"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Battery, Eye, EyeOff } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/hooks/use-auth"
import { ThemeToggle } from "@/components/theme-toggle"

export default function RegisterPage() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const { login } = useAuth()

  // Add robot ID state
  const [robotId, setRobotId] = useState("")
  const [robotIdError, setRobotIdError] = useState("")

  // Add validation for robot ID in handleSubmit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const staffId = (form.elements.namedItem("staffId") as HTMLInputElement).value
    const department = (form.elements.namedItem("department") as HTMLInputElement).value

    // Reset error state
    setRobotIdError("")

    if (password !== confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match",
        variant: "destructive",
      })
      return
    }

    // Validate robot ID
    if (!robotId.trim()) {
      setRobotIdError("Robot ID is required")
      return
    }

    setIsLoading(true)

    try {
      // In a real app, this would validate the robot ID against a database
      // For demo purposes, we'll simulate a validation check
      const isValidRobotId = robotId.startsWith("MSDS-") && robotId.length >= 8

      if (!isValidRobotId) {
        setRobotIdError("Invalid robot ID format or robot not available")
        setIsLoading(false)
        return
      }

      // In a real app, this would make an API call to your backend
      // For demo purposes, we'll simulate a successful registration
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Call the login function from auth context to log the user in after registration
      login({ email, name, staffId, department, robotId })

      toast({
        title: "Registration successful",
        description: "Your account has been created",
      })

      router.push("/")
    } catch (error) {
      toast({
        title: "Registration failed",
        description: "There was a problem creating your account",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center gradient-bg">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-lg px-4 mx-auto">
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-2 bg-white/10 dark:bg-white/5 p-3 rounded-full">
            <Battery className="h-8 w-8 text-white" />
            <h1 className="text-2xl font-bold text-white">MSDS</h1>
          </div>
        </div>

        <Card className="auth-card w-full max-w-lg">
          <CardHeader>
            <CardTitle className="text-2xl">Create an Account</CardTitle>
            <CardDescription>Enter your details to create your account</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    placeholder="John Doe"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="staffId">Staff ID</Label>
                  <Input id="staffId" placeholder="STAFF-1234" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input id="department" placeholder="Medical Robotics" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-1 top-1 h-7 w-7 p-0"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm Password</Label>
                  <div className="relative">
                    <Input
                      id="confirm-password"
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-1 top-1 h-7 w-7 p-0"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      <span className="sr-only">{showConfirmPassword ? "Hide password" : "Show password"}</span>
                    </Button>
                  </div>
                </div>

                {/* Add robot ID field after password fields */}
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="robotId">Robot ID/Serial Number</Label>
                  <Input
                    id="robotId"
                    placeholder="MSDS-1234"
                    value={robotId}
                    onChange={(e) => {
                      setRobotId(e.target.value)
                      setRobotIdError("")
                    }}
                    className={robotIdError ? "border-red-500" : ""}
                    required
                  />
                  {robotIdError && <p className="text-sm text-red-500 mt-1">{robotIdError}</p>}
                  <p className="text-xs text-muted-foreground">Enter the ID of the robot you'll be managing</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Creating account..." : "Register"}
              </Button>
              <p className="text-sm text-center text-muted-foreground">
                Already have an account?{" "}
                <Link href="/login" className="text-primary hover:underline">
                  Login
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
